
document.querySelectorAll(".registerBtn").forEach(button => {
  button.onclick = () => {
    const eventName = button.closest(".event").querySelector("h2").innerText;
    alert(`You registered for ${eventName}!`);
  };
});


document.getElementById("categoryFilter").onchange = function () {
  const selected = this.value;
  document.querySelectorAll(".event").forEach(event => {
    const category = event.dataset.category;
    event.style.display = (selected === "all" || category === selected) ? "block" : "none";
  });
};


document.getElementById("searchBar").addEventListener("keydown", function () {
  const query = this.value.toLowerCase();
  document.querySelectorAll(".event").forEach(event => {
    const name = event.dataset.name.toLowerCase();
    event.style.display = name.includes(query) ? "block" : "none";
  });
});
