
const events = [
  { id: 1, name: "Tech Talk", date: "2025-06-10" },
  { id: 2, name: "Music Fest", date: "2025-06-15" },
  { id: 3, name: "Food Carnival", date: "2025-06-20" }
];

const container = document.querySelector("#events-container");


function renderEvents() {
  container.innerHTML = "";
  events.forEach(event => {
    const card = document.createElement("div");
    card.className = "event-card";
    card.setAttribute("id", `event-${event.id}`);

    const title = document.createElement("h3");
    title.textContent = event.name;

    const date = document.createElement("p");
    date.textContent = `Date: ${event.date}`;

    const button = document.createElement("button");
    button.textContent = "Register";
    button.addEventListener("click", () => toggleRegistration(card, button));

    card.appendChild(title);
    card.appendChild(date);
    card.appendChild(button);

    container.appendChild(card);
  });
}


function toggleRegistration(card, button) {
  if (card.classList.contains("registered")) {
    card.classList.remove("registered");
    button.textContent = "Register";
  } else {
    card.classList.add("registered");
    button.textContent = "Cancel Registration";
  }
}


renderEvents();
