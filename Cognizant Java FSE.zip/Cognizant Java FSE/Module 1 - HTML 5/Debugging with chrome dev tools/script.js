function changeText() {
  console.log("Button clicked!");
  const message = document.getElementById("message");
  message.innerText = "You clicked the button!";
}
