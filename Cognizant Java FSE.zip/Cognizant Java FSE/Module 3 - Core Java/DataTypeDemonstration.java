public class DataTypeDemonstration{
    public static void main(String[] args) {
        int a = 81;
        float b = 31.2f;
        double c = 20.05;
        char d = 'R';
        boolean e = true;
        System.out.println("Integer value: " + a);
        System.out.println("Float value: " + b);
        System.out.println("Double value: " + c);
        System.out.println("Character value: " + d);
        System.out.println("Boolean value: " + e);
    }
}
